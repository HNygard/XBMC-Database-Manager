<?php
	$footer='Copyright &copy; 2011 Vicious';
	$heading='XBMC Database Manager';
	$host = "localhost";
	$username = "xbmc";
	$password = "xbmc";
	$database = "xbmc_video";
?>
