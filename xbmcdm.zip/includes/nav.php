<div id="nav">
	<a href="#">Movies</a>
	<a href="#">TV-Shows</a>
	<a href="#">Music</a>
</div>
