<div id="sidebar">
	<?php
		
		foreach (dbquery("SELECT c00,idMovie FROM movie") as $row)
		{
			echo "<a href=\"?action=getmovie&movieid=" . $row['idMovie'] . "\">" . $row['c00'] . "</a><br>";
		}
	?>
</div>
