<?php include('variables/variables.php'); ?>
<div id="header">
	<h2><?php echo $heading ?></h2>
</div> <!-- end #header -->
