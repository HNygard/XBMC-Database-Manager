<?php
		function dbquery($query)
		{
			global $hostname, $database, $username, $password;
			try 
			{
				$dbconn = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
				$result = $dbconn->query($query);
				$dbconn = null;
			}
			catch(PDOException $e)
			{
				$result = $e->getMessage();
			}
			return $result;
		}
		
		function getTitle($id)
		{
			$q = "SELECT c00 FROM movie WHERE idMovie = " . $id;
			foreach (dbquery($q) as $temp)
			{
				$title = $temp['c00'];
			}
			return $title;
		}
		
		function getFile($id)
		{
			$q = "SELECT idFile FROM movie WHERE idMovie = " . $id;
			foreach (dbquery($q) as $temp)
			{
					$idfile = $temp['idFile'];
			}
			$q = "SELECT idPath,strFilename FROM files WHERE idFile = " . $idfile;
			foreach (dbquery($q) as $temp)
			{
					$filename = $temp['strFilename'];
					$idpath = $temp['idPath'];
			}
			$q = "SELECT strPath FROM path WHERE idPath = ". $idpath;
			foreach (dbquery($q) as $temp)
			{
					$path = $temp['strPath'];
			}
			return $path.$filename;
		}
		
		
		function PrintInfo($id)
		{
			$q = "SELECT c00,c01,c02,c03,c04,c05,c06,c07,c09,c11,c14,c15,c18 FROM movie WHERE idMovie = " . $id;
			foreach (dbquery($q) as $temp)
			{
				$title = $temp['c00'];
				$plot = $temp['c01'];
				$outline = $temp['c02'];
				$tagline = $temp['c03'];
				$votes = $temp['c04'];
				$rating = $temp['c05'];
				$writer = $temp['c06'];
				$year = $temp['c07'];
				$imdb = $temp['c09'];
				$runtime = $temp['c11'];
				$genre = $temp['c14'];
				$director = $temp['c15'];
				$studio = $temp['c18'];
			}
			?>
			<table border="0">
				<tr>
					<td>
						<?php echo "<h1>" . $title . "</h1>"; ?>
					</td>
				</tr>
			</table>
			<table border="1">
				<tr>
					<td>
						<h5>Director</h5>
					</td>
					<td>
						<?php echo "<p>" . $director . "</p>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<h5>Writer</h5>
					</td>
					<td>
						<?php echo "<p>" . $writer . "</p>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<h5>Studio</h5>
					</td>
					<td>
						<?php echo "<p>" . $studio . "</p>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<h5>Genre</h5>
					</td>
					<td>
						<?php echo "<p>" . $genre . "</p>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<h5>Year</h5>
					</td>
					<td>
						<?php echo "<p>" . $year . "</p>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<h5>Runtime</h5>
					</td>
					<td>
						<?php echo "<p>" . $runtime . " minutes</p>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<h5>Rating</h5>
					</td>
					<td>
						<?php echo "<p>" . $rating . " (" . $votes . " votes)</p>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<h5>Tagline</h5>
					</td>
					<td>
						<?php echo "<p>" . $tagline . "</p>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<h5>Plot outline</h5>
					</td>
					<td>
						<?php echo "<p>" . $outline . "</p>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<h5>File</h5>
					</td>
					<td>
						<?php echo "<p>" . getFile($id) . "</p>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<h5>IMDB</h5>
					</td>
					<td>
						<?php echo "<a href=\"http://www.imdb.org/title/" . $imdb . "\">" . "IMDB" . "</a><br>"; ?>
					</td>
				</tr>
			</table>
			<table border="0">
				<tr>
					<td>
						<?php echo "<h5>Plot</h5>"; ?>
					</td>
				</tr>
				<tr>
					<td>
						<?php echo "<p>" . $plot . "<p>"; ?>
					</td>
				</tr>
			</table>
			<?php
		}
?>
