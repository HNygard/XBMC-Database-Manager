<div id="footer">
	<?php
		include('variables/variables.php');
		echo "<p>" . $footer . "</p>"
	?>
</div>
