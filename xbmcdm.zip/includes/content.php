<!--<div id="content">-->
<?php
	$id = $_GET["movieid"];
	if ($_GET["action"] == "getmovie")
	{
		PrintInfo($id);
		#echo "<h1>" . getTitle($id) . "</h1>";
	}
	else
	{
		echo "Uknown";
	}
?>
<!--</div> <!-- end #content -->
